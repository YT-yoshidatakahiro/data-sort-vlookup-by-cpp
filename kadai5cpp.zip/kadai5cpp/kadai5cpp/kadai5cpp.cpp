﻿//課題5

//課題5
#include "pch.h"

//読込先
string dat1 = "D:\\課題\\課題5cpp\\kadai5cpp\\data1.csv";
string dat2 = "D:\\課題\\課題5cpp\\kadai5cpp\\data2.csv";

//読込設定
ifstream filestream1(dat1);
ifstream filestream2(dat2);

void getdatarr1(string x_1[1])
{
	filestream1 >> x_1[0]; //cerr << x << endl;
}
void getdatarr2(string y_1[1])
{
	filestream2 >> y_1[0]; //cerr << y << endl;
}

int main()
{
	//書き込み準備
	// string datw = "D:\\課題\\課題4cpp\\kadai4cpp\\data3.csv";
		//ofstream err_w;
		//err_w = ofstream(datw, ios::out);

		//見出し読込
		string test1[1];
	string test2[1];
	getdatarr1(test1);
	getdatarr2(test2);

	//初期値
	int num1 = 0;
	int num2 = 0;
	int sum1 = 0;
	int sum2 = 0;
	string name1;
	////処理開始
	while (!filestream1.eof()) {

		getdatarr1(test1);

		num1 = atoi(test1[0].substr(0, test1[0].find(",")).c_str());
		name1 = test1[0].substr(test1[0].find(",") + 1).c_str();


		sum2 = 0;
		num2 = num1;
		//合計処理開始
		while (!filestream2.eof() && num1 == num2) {

			getdatarr2(test2);

			num2 = atoi(test2[0].substr(0,
				test2[0].find(",")).c_str());

			if (num1 == num2) {

				sum1 = atoi(test2[0].substr(test2[0].find(",") + 1).c_str());

					sum2 += sum1;
			}
		}
		cout << num1 << " " << name1 << " " << sum2 << endl;
	}
}